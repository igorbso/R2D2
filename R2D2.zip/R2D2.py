import os
import sys

proteoma = f"{sys.argv[1]}"

os.system("mkdir results")

#BLASTp contra genoma humano
os.system(f"diamond blastp -d ./lib/Human.faa -q {proteoma} -o tmp.txt -e 0.005 --id 50")

#Filtra proteínas homólogas
os.system(f"python ./lib/filter.py {proteoma}")

#BLASTp contra DEG
os.system(f"diamond blastp -d ./lib/DEG.fasta -q ./results/filtered.fasta -o tmp.txt -e 0.0001")

#Filtra proteínas não homólogas
os.system(f"python ./lib/filter2.py ./results/filtered.fasta")

#BLASTp contra VFDB
os.system(f"diamond blastp -d ./lib/VFDB.fasta -q ./results/filtered2.fasta -o tmp.txt -e 0.0001")

#Filtra proteínas não homólogas
os.system(f"python ./lib/filter3.py ./results/filtered2.fasta")

#BLASTp contra DrugBank
os.system(f"diamond blastp -d ./lib/drugbank.fasta -q ./results/filtered3.fasta -o tmp.txt -e 0.0001")

#Filtra proteínas não homólogas
os.system(f"python ./lib/filter4.py ./results/filtered3.fasta")

#BLASTp contra microbiota
os.system(f"diamond blastp -d ./lib/gut.fasta -q ./results/filtered4.fasta -o tmp.txt -e 0.005 --id 50")

#Filtra proteínas homólogas
os.system(f"python ./lib/filter5.py ./results/filtered4.fasta")

print("Os resultados foram salvos na pasta RESULTS!")
